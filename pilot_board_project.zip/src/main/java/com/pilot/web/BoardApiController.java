package com.pilot.web;

import com.pilot.domain.board.Board;
import com.pilot.dto.board.BoardRequestDTO;
import com.pilot.dto.board.BoardResponseDTO;
import com.pilot.dto.board.BoardUpdateRequestDTO;
import com.pilot.service.board.BoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.web.bind.annotation.*;

import javax.persistence.Id;

@RequiredArgsConstructor
@RestController
public class BoardApiController {

    private final BoardService boardService;

    @PostMapping("/api/v1/board")
    public Long save(@RequestBody BoardRequestDTO requestDTO){
        return boardService.save(requestDTO);
    }

    @PutMapping("/api/v1/board/{id}")
    public Long update(@PathVariable Long id, @RequestBody BoardUpdateRequestDTO requestDTO){
        return boardService.update(id, requestDTO);
    }

    @GetMapping("/api/v1/board/list")
    public Page<BoardResponseDTO> findList(
            @PageableDefault(page=0,size=10,sort="id",direction = Sort.Direction.DESC) Pageable pageable,
            @RequestParam(name="keyword",defaultValue = "") String keyword
    ){
        return boardService.findList(keyword,pageable);
    }

    @GetMapping("/api/v1/board/{id}")
    public BoardResponseDTO findById(@PathVariable Long id){
        return boardService.findById(id);
    }

    @DeleteMapping("/api/v1/board/{id}")
    public Long delete(@PathVariable Long id){
        boardService.delete(id);
        return id;
    }

    @GetMapping("/api/v1/board/searchTitle")
    public Page<Board> searchTitle(
            @PageableDefault(page=0,size=10,sort="id",direction = Sort.Direction.DESC) Pageable pageable,
            @RequestParam(name="keyword",defaultValue = "") String keyword
    ){
       return boardService.findByTitleContaining(keyword,pageable);
    }

    @GetMapping("/api/v1/board/searchTitleContent")
    public Page<Board> searchTitleContent(
            @PageableDefault(page=0,size=10,sort="id",direction = Sort.Direction.DESC) Pageable pageable,
            @RequestParam(name="title", defaultValue = "") String title,
            @RequestParam(name="content", defaultValue = "") String content
    ){
        return boardService.findByTitleContainingOrContentContaining(title, content,pageable);
    }


}
