package com.pilot.web;

import com.pilot.dto.board.BoardRequestDTO;
import com.pilot.dto.user.UserRequestDTO;
import com.pilot.service.user.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

@RequiredArgsConstructor
@RestController
public class UserApiController {

    private final UserService userService;

    @PostMapping("/api/v1/signup")
    public Long save(@RequestBody UserRequestDTO userRequestDTO) throws Exception {
        return userService.save(userRequestDTO);
    }

    @PutMapping("/api/v1/user/update")
    public Long update(@RequestBody UserRequestDTO userRequestDTO) throws Exception{
        return userService.update(userRequestDTO);
    }

}
