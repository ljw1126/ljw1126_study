package com.pilot.web;

import com.pilot.dto.user.UserRequestDTO;
import com.pilot.service.user.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

@Controller
@RequiredArgsConstructor
public class UserController {

    private final UserService userService;

    @GetMapping("/signup")
    public String signup(){
        return "user/signup";
    }

    @PostMapping("/signup")
    public Long signup(@RequestBody UserRequestDTO userRequestDTO) throws Exception {
        return userService.save(userRequestDTO);
    }

    @GetMapping("/login")
    public String login(){
        return "user/login";
    }

    @PostMapping("/login")
    public String login(UserRequestDTO userRequestDTO){
        return "index";
    }

}
