package com.pilot.web;

import com.pilot.dto.board.BoardResponseDTO;
import com.pilot.dto.board.PagingDTO;
import com.pilot.service.board.BoardService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.data.web.PageableDefault;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.Optional;

@RequiredArgsConstructor
@Controller
public class BoardController {

    private final BoardService boardService;

    @GetMapping("/board/save")
    public String boardSave(){
        return "board/save";
    }

    @GetMapping("/board/update/{id}")
    public String boardUpdate(@PathVariable Long id, Model model){
        model.addAttribute("board", boardService.findById(id));
        return "board/update";
    }

    @GetMapping("/board/list")
    public String boardList(
            @PageableDefault(page=0,size=10,sort="id",direction = Sort.Direction.DESC) Pageable pageable,
            @RequestParam(name="keyword", required = false, defaultValue = "") String keyword,
            Model model){

        Page<BoardResponseDTO> boards = boardService.findList(keyword, pageable);
        PagingDTO paging = new PagingDTO(boards.getNumber(), boards.getSize(), boards.getPageable().getPageSize(), boards.getTotalElements());

        model.addAttribute("paging",paging);
        model.addAttribute("boards",boards);
        model.addAttribute("keyword",keyword);

        return "board/list";
    }

    @GetMapping("board/detail/{id}")
    public String boardDetail(@PathVariable Long id, Model model){
        model.addAttribute("board", boardService.findDetail(id));
        return "board/detail";
    }



}
