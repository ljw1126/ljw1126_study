package com.pilot.dto.board;

import lombok.Getter;

import java.util.ArrayList;

@Getter
public class PagingDTO {

    private Long totalCount; // 총 게시글 수
    private int totalPages; // 총 페이지 수
    private int currentPage; //

    private boolean isFirst = false;
    private boolean isLast = false;
    private boolean isPrev = false;
    private boolean isNext = false;
    private boolean isEmpty = false;

    private int startPage;
    private int endPage;
    private ArrayList<Integer> pages;
    private int prevPage;
    private int nextPage;

    private int size =10;
    private int pageGroupSize = 10; // 페이지 번호 그룹 수

    public PagingDTO(int currentPage, int size, int pageGroupSize, Long totalCount){
        this.currentPage = currentPage == 0 ? 1 : currentPage+1;
        this.size = size;
        this.pageGroupSize = pageGroupSize;
        this.totalCount = totalCount;

        setPagingInfo();
    }

    private void setPagingInfo(){
        startPage = currentPage - ((currentPage - 1) % pageGroupSize);
        endPage = startPage - 1 + pageGroupSize;

        totalPages = (int)(totalCount/size + (totalCount%size == 0 ? 0 : 1));

        if(totalCount == 0) isEmpty = true;

        if(startPage > pageGroupSize && currentPage > pageGroupSize){
            isPrev = true;
            prevPage = startPage - 1;
        }

        if(endPage > totalPages){
            endPage = totalPages;
        }

        if(endPage != totalPages){
            isNext = true;
            nextPage = endPage + 1;
        }

        pages = new ArrayList();
        for(int i = startPage ; i <= endPage; i++){
            pages.add(i);
        }
    }

    @Override
    public String toString() {
        return "PagingDTO{" +
                "totalCount=" + totalCount +
                ", totalPages=" + totalPages +
                ", currentPage=" + currentPage +
                ", isFirst=" + isFirst +
                ", isLast=" + isLast +
                ", isPrev=" + isPrev +
                ", isNext=" + isNext +
                ", isEmpty=" + isEmpty +
                ", startPage=" + startPage +
                ", endPage=" + endPage +
                ", pages=" + pages +
                ", prevPage=" + prevPage +
                ", nextPage=" + nextPage +
                ", size=" + size +
                ", pageGroupSize=" + pageGroupSize +
                '}';
    }
}
