package com.pilot.dto.board;

import com.pilot.domain.board.Board;
import lombok.Getter;

import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Optional;

@Getter
public class BoardResponseDTO {

    private Long id;
    private String title;
    private String content;
    private Integer viewCnt;
    private String createdDate;
    private String modifiedDate;

    public BoardResponseDTO(Board board) {
        this.id = board.getId();
        this.title = board.getTitle();
        this.content = board.getContent();
        this.viewCnt = board.getViewCnt();
        this.createdDate = toStringDateTime(board.getCreatedDate());
        this.modifiedDate = toStringDateTime(board.getModifiedDate());
    }

    private String toStringDateTime(LocalDateTime localDateTime){
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        return  Optional.ofNullable(localDateTime)
                .map(formatter::format)
                .orElse("");
    }


}
