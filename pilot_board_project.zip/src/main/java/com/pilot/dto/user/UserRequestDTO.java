package com.pilot.dto.user;

import com.pilot.domain.user.User;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@NoArgsConstructor
public class UserRequestDTO {

    private String username;
    private String password;
    private String email;
    private String authority;

    @Builder
    public UserRequestDTO(String username, String password, String email, String authority) {
        this.username = username;
        this.password = password;
        this.email = email;
        this.authority = authority;
    }

    public User toEntity(){
        return User.builder()
                .username(username)
                .password(password)
                .email(email)
                .authority(authority)
                .build();
    }

}
