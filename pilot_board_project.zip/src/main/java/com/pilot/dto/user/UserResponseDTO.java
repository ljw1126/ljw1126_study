package com.pilot.dto.user;

public class UserResponseDTO {
}
