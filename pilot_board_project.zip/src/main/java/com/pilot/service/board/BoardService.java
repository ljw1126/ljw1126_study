package com.pilot.service.board;

import com.pilot.domain.board.Board;
import com.pilot.domain.board.BoardRepository;
import com.pilot.dto.board.BoardRequestDTO;
import com.pilot.dto.board.BoardResponseDTO;
import com.pilot.dto.board.BoardUpdateRequestDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@RequiredArgsConstructor
@Service
public class BoardService {

    private final BoardRepository boardRepository;

    @Transactional
    public Long save(BoardRequestDTO requestDTO) {
        return boardRepository.save(requestDTO.toEntity()).getId();
    }

    @Transactional
    public Long update(Long id, BoardUpdateRequestDTO requestDTO){
        Board board = boardRepository.findById(id)
                                     .orElseThrow(()-> new IllegalArgumentException("해당 게시글이 없습니다. id = " + id));;

        board.update(requestDTO.getTitle(), requestDTO.getContent());
        return id;
    }

    @Transactional(readOnly = true)
    public BoardResponseDTO findById(Long id){
        Board board = boardRepository.findById(id)
                .orElseThrow(()-> new IllegalArgumentException("해당 게시글이 없습니다. id = " + id));;

        return new BoardResponseDTO(board);
    }

    @Transactional
    public void delete(Long id){
        Board board = boardRepository.findById(id)
                .orElseThrow(()-> new IllegalArgumentException("해당 게시글이 없습니다. id = " + id));;
        board.delete("N");
    }


    @Transactional(readOnly = true) // p148
    public List<Board> findAll(){
        return boardRepository.findAll();
    }

    @Transactional(readOnly = true) // p148
    public Page<Board> findAll(Pageable pageable){
        return boardRepository.findAll(pageable);
    }

    @Transactional(readOnly = true)
    public Page<Board> findByTitleContaining(String keyword, Pageable pageable){
        return boardRepository.findByTitleContaining(keyword,pageable);
    }

    @Transactional(readOnly = true)
    public Page<Board> findByTitleContainingOrContentContaining(String title, String content, Pageable pageable){
        return boardRepository.findByTitleContainingOrContentContaining(title, content,pageable);
    }

    @Transactional(readOnly = true)
    public Page<BoardResponseDTO> findList(String keyword, Pageable pageable){
        return boardRepository.findList(keyword,pageable);
    }

    @Transactional
    public BoardResponseDTO findDetail(Long id){
        Board board = boardRepository.findById(id)
                .orElseThrow(()-> new IllegalArgumentException("해당 게시글이 없습니다. id = " + id));

        board.updateViewCnt(); // 조회수 업데이트

        return new BoardResponseDTO(board);
    }

}
