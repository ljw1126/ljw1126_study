package com.pilot.service.user;

import com.pilot.domain.user.User;
import com.pilot.domain.user.UserRepository;
import com.pilot.dto.board.BoardRequestDTO;
import com.pilot.dto.user.UserRequestDTO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@RequiredArgsConstructor
@Service
public class UserService {

    private final UserRepository userRepository;


    @Transactional
    public Long save(UserRequestDTO requestDTO){

        if(userRepository.findByUsername(requestDTO.getUsername()) != null) return -1L;
//
//        requestDTO.setAuthority("ROLE_USER");

        return userRepository.save(requestDTO.toEntity()).getId();
    }


    @Transactional
    public Long update(UserRequestDTO userRequestDTO) throws Exception {

        User user = userRepository.findByUsername(userRequestDTO.getUsername());
        if(user == null){
            throw new Exception("사용자 정보가 존재하지 않습니다.");
        }

        user.update(userRequestDTO.getPassword(), userRequestDTO.getEmail());

        return user.getId();
    }

    @Transactional(readOnly = true)
    public User findByUsername(String username){
        return userRepository.findByUsername(username);
    }

    @Transactional
    public User _save(UserRequestDTO requestDTO) throws Exception{

        if(userRepository.findByUsername(requestDTO.getUsername()) != null) {
            throw new Exception("중복된 사용자가 존재합니다.");
        }
        return userRepository.save(requestDTO.toEntity());
    }

}
