package com.pilot.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.web.config.PageableHandlerMethodArgumentResolverCustomizer;

@Configuration
public class PagingConfig {

    @Bean
    public PageableHandlerMethodArgumentResolverCustomizer pageableHandlerMethodArgumentResolverCustomizer(){
        return p -> {
            p.setOneIndexedParameters(true); // 1부터 시작
            p.setMaxPageSize(1000); // 최대 사이즈
        };
    }
}
