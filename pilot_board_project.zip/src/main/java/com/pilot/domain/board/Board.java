package com.pilot.domain.board;


import com.pilot.domain.BaseTimeEntity;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;

import javax.persistence.*;

@Getter
@NoArgsConstructor
@Entity
public class Board extends BaseTimeEntity {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(length=500, nullable = false)
    private String title;

    @Column(columnDefinition = "text", nullable = true) // 텍스트 타입 변경
    private String content;

    @Column(columnDefinition="char(1)") // 삭제시 false
    private String useYn = "Y";    // 사용여부

    private Integer viewCnt = 0;    // 조회수

    //테스트 사용
    @Builder
    public Board(String title, String content) {
        this.title = title;
        this.content = content;
    }

    public void update(String title, String content){
        this.title = title;
        this.content = content;
    }

    public void delete(String useYn){
        this.useYn = useYn;
    }

    public void updateViewCnt(){
        this.viewCnt += 1;
    }
}
