package com.pilot.domain.board;

import com.pilot.dto.board.BoardResponseDTO;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.PagingAndSortingRepository;
import org.springframework.data.repository.query.Param;

import java.util.List;
import java.util.Optional;

public interface BoardRepository extends PagingAndSortingRepository<Board,Long> {

    //Optional<Board> findByBoardId(Long boardId);

    List<Board> findAll();
    Page<Board> findAll(Pageable pageable);
    Page<Board> findByTitleContaining(String keyword, Pageable pageable);

    @Query("SELECT b FROM Board b WHERE b.title like %:title% or b.content like %:content% ")
    Page<Board> findByTitleContainingOrContentContaining(@Param("title")String title, @Param("content")String content, Pageable pageable);


    @Query("SELECT b FROM Board b WHERE b.useYn = 'Y' and ( b.title like %:keyword% or b.content like %:keyword% ) ")
    Page<BoardResponseDTO> findList(@Param("keyword") String keyword, Pageable pageable);

}
