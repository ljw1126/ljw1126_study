var main = {
    init : function(){
        var _this = this;
        $('#btn_save').on('click',function(e){
            e.preventDefault();
            _this.save();
        });

        $('#btn_update').on('click', function(e){
            e.preventDefault();
            _this.update();
        });

        $('#btn_delete').on('click',function(e){
            e.preventDefault();
            _this.delete();
        })
    },
    save : function(){

        // 작성자 추가 예정
        var data = {
            title: $('#title').val(),
            content: $('#content').val()
        };
        /*
            dataType - 서버에서 받을 타입
            contentType - 클라이언트에서 보내는 데이터 타입
         */
        $.ajax({
                type: 'POST',
                url: '/api/v1/board',
                dataType: 'json',
                contentType: 'application/json; charset=utf-8',
                data: JSON.stringify(data),
                success: function (result) {
                    alert('게시글 등록 되었습니다.');
                    window.location.href = '/board/list';
                },
                error: function(request, status, error){
                    alert("Error Code (" + request.status + ")\n 관리자에게 문의하시길 바랍니다.");
                    consoleo.log("code:"+request.status+", message:"+request.responseText + ", error:"+error);
                }
            }
         );
    },
    update : function(){
        var data = {
            title : $('#title').val(),
            content : $('#content').val()
        };

        var id = $('#id').val();

        $.ajax({
            type : 'PUT',
            url : '/api/v1/board/'+id,
            contentType: 'application/json; charset=utf-8',
            dataType: 'json',
            data : JSON.stringify(data),
            success : function(result){
                alert('게시글 수정 되었습니다.')
                window.location.href = '/board/list';
            },
            error: function(request, status, error){
                alert("Error Code (" + request.status + ")\n 관리자에게 문의하시길 바랍니다.");
                consoleo.log("code:"+request.status+", message:"+request.responseText + ", error:"+error);
            }
        })
    },
    delete : function(){

        if(confirm('해당 게시글 삭제 하시겠습니까?')){
            var id = $('#id').val();

            $.ajax({
                type:'DELETE',
                url :'/api/v1/board/'+id,
                dataType : 'json',
                contentType : 'appplication/json; charset=utf-8',
                success :function(result){
                    alert('게시글 삭제 되었습니다.');
                    window.location.href = '/board/list';
                },
                error: function(request, status, error){
                    alert("Error Code (" + request.status + ")\n 관리자에게 문의하시길 바랍니다.");
                    consoleo.log("code:"+request.status+", message:"+request.responseText + ", error:"+error);
                }
            });
        }

    }
} //end : main

main.init();