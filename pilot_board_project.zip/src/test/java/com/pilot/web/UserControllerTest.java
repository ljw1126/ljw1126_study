package com.pilot.web;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pilot.domain.board.BoardRepository;
import com.pilot.domain.user.User;
import com.pilot.domain.user.UserRepository;
import com.pilot.dto.user.UserRequestDTO;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;

import javax.transaction.Transactional;

import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.Matchers.containsString;

@SpringBootTest
@AutoConfigureMockMvc
class UserControllerTest {

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private MockMvc mockMvc;

    @DisplayName("[GET]회원가입 페이지")
    @Test
    void signup_get() throws Exception{
        mockMvc.perform(get("/signup").accept(MediaType.TEXT_HTML))
                        .andExpect(status().isOk())
                        .andExpect(content().string(containsString("회원가입")))
                        .andDo(print())
        ;
    }

    @Test
    void signup() throws Exception {
        mockMvc.perform(
                post("/signup")
                        .contentType(MediaType.APPLICATION_JSON_VALUE)
                        .content(asJsonString(UserRequestDTO.builder()
                                                            .username("user123")
                                                            .password("123")
                                                            .email("test@treenod.com")
                                .build()
                        ))

                  )
                .andExpect(status().is3xxRedirection())
                .andDo(print());

        User user = userRepository.findByUsername("user123");

        Assertions.assertThat(user.getUsername()).isEqualTo("user123");

        System.out.println(user.toString());

    }

    public static String asJsonString(final Object obj) {
        try {
            return new ObjectMapper().writeValueAsString(obj);
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }
}