package com.pilot.web;

import com.pilot.domain.board.Board;
import com.pilot.domain.board.BoardRepository;
import com.pilot.dto.board.BoardRequestDTO;
import com.pilot.dto.board.BoardResponseDTO;
import com.pilot.dto.board.BoardUpdateRequestDTO;
import com.pilot.dto.board.PagingDTO;
import org.assertj.core.api.Assertions;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.boot.web.server.LocalServerPort;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;
import java.util.Optional;

import static org.springframework.test.web.servlet.result.MockMvcResultHandlers.print;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.content;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;


@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class BoardApiControllerTest {

    private MockMvc mvc;

    @LocalServerPort
    private int port;

    @Autowired
    private TestRestTemplate restTemplate;

    @Autowired
    private BoardRepository boardRepository;

    @DisplayName("게시글 작성 API 호출 테스트")
    @Test
    public void board_save() throws Exception{
        //given
        String title = "게시글 작성 테스트";
        String content = "게시글 내용입니다.";

        BoardRequestDTO requestDTO = BoardRequestDTO.builder()
                .title(title)
                .content(content)
                .build();

        String url = "http://localhost:"+port+"/api/v1/board";

        //when
        ResponseEntity<Long> responseEntity
                = restTemplate.postForEntity(url, requestDTO, Long.class); // post 요청함

        //then
        Assertions.assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        Assertions.assertThat(responseEntity.getBody()).isGreaterThan(0L);

        List<Board> listAll = boardRepository.findAll();
        Assertions.assertThat(listAll.get(0).getTitle()).isEqualTo(title);
        Assertions.assertThat(listAll.get(0).getContent()).isEqualTo(content);
    }

    @DisplayName(" update 후 갱신 데이터 확인 ")
    @Test
    public void board_update() throws Exception{
        //given
        Board savedBoard = boardRepository.save(
                            Board.builder()
                                 .title("테스트title")
                                 .content("테스트content")
                                 .build()
        );

        Long updateId = savedBoard.getId();
        String expectedTitle = "테스트Title수정";
        String expectedContent = "테스트Content수정";

        BoardUpdateRequestDTO requestDTO = BoardUpdateRequestDTO.builder()
                                                                .title(expectedTitle)
                                                                .content(expectedContent)
                                                                .build();

        String url = "http://localhost:"+port+"/api/v1/board/"+updateId;

        HttpEntity<BoardUpdateRequestDTO> requestEntity = new HttpEntity<>(requestDTO);

        //when
        ResponseEntity<Long> responseEntity = restTemplate.exchange(url, HttpMethod.PUT, requestEntity,Long.class);

        //then
        Assertions.assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        Assertions.assertThat(responseEntity.getBody()).isGreaterThan(0L);

        List<Board> all = boardRepository.findAll();
        Assertions.assertThat(all.get(0).getTitle()).isEqualTo(expectedTitle);
        Assertions.assertThat(all.get(0).getContent()).isEqualTo(expectedContent);

    }


    @DisplayName("boardID 로 Board객체 호출 테스트")
    @Test
    public void board_findByBoardIdTest() throws Exception{
        //given
        String title = "테스트 title";
        String content = "테스트 content";

        Board savedBoard = boardRepository.save(
                Board.builder()
                        .title(title)
                        .content(content)
                        .build()
        );

        Long findBoardId = savedBoard.getId();

        String url = "http://localhost:"+port+"/api/v1/board/"+findBoardId;

        //when
        ResponseEntity<BoardResponseDTO> responseEntity
                = restTemplate.getForEntity(url, BoardResponseDTO.class); // get 요청

        //then
        Assertions.assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
    }

    @DisplayName("저장 후 삭제 테스트")
    @Test
    public void board_delete() throws Exception{
        //given
        String title = "테스트 title";
        String content = "테스트 content";

        Board savedBoard = boardRepository.save(
                Board.builder()
                        .title(title)
                        .content(content)
                        .build()
        );

        Long boardId = savedBoard.getId();

        String url = "http://localhost:"+port+"/api/v1/board/"+boardId;

        HttpEntity<String> requestEntity = null;
        //when
        ResponseEntity<Long> responseEntity
                =restTemplate.exchange(url, HttpMethod.DELETE, requestEntity ,Long.class);

        //then
        Assertions.assertThat(responseEntity.getStatusCode()).isEqualTo(HttpStatus.OK);
        Assertions.assertThat(responseEntity.getBody()).isGreaterThan(0L);

        System.out.println(responseEntity.getBody());

    }

    @DisplayName("게시판 목록 호출 테스트(페이징, title or content 검색)")
    @Test
    public void board_searchlistTest() throws Exception{
        int size = 3;
        String keyword = "";
        Pageable pageable = PageRequest.of(1,size);
        Page<BoardResponseDTO> list = boardRepository.findList(keyword,  pageable);

        Assertions.assertThat(list.getSize()).isEqualTo(size);

        PagingDTO pagingDTO = new PagingDTO(list.getNumber(), list.getSize(), list.getPageable().getPageSize(), list.getTotalElements());
        System.out.println(pagingDTO.toString());

        Assertions.assertThat(pagingDTO.isEmpty()).isEqualTo(true);
    }



    @DisplayName("게시판 상세 호출 테스트")
    @Test
    public void board_detail() throws Exception {

        Long test_id = 20L;
        Optional<BoardResponseDTO> board = boardRepository.findById(test_id).map(BoardResponseDTO::new);

        Assertions.assertThat(board.get().getId()).isEqualTo(test_id);
    }



}